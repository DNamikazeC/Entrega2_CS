﻿using System;
using System.Collections.Generic;

namespace PartidoBasket
{
    // interfaz que define las acciones de un jugador
    interface IJugador
    {
        void MostrarInformacion();
    }

    // clase Jugador que implementa la interfaz IJugador
    class Jugador : IJugador
    {
        // propiedades privadas
        private string nombre;
        private string posicion;
        private int rendimiento;

        // constructor que inicializa las propiedades del jugador
        public Jugador(string nombre, string posicion, int rendimiento)
        {
            if (rendimiento < 0 || rendimiento > 10)
            {
                throw new ArgumentException("El rendimiento debe estar entre 0 y 10.");
            }
            this.nombre = nombre;
            this.posicion = posicion;
            this.rendimiento = rendimiento;
        }

        // metodo para obtener el rendimiento del jugador
        public int GetRendimiento()
        {
            return rendimiento;
        }

        // implementación del metodo de la interfaz para mostrar información del jugador
        public void MostrarInformacion()
        {
            Console.WriteLine($"Nombre: {nombre}, Posición: {posicion}, Rendimiento: {rendimiento}");
        }
    }

    // clase Equipo que contiene una lista de jugadores
    class Equipo
    {
        // lista privada de jugadores
        private List<Jugador> jugadores;

        // constructor que inicializa la lista de jugadores
        public Equipo()
        {
            jugadores = new List<Jugador>();
        }

        // metodo para agregar un jugador al equipo
        public void AgregarJugador(Jugador jugador)
        {
            if (jugadores.Count < 3) // Verificar que el equipo no tenga más de 3 jugadores
            {
                jugadores.Add(jugador);
            }
        }

        // metodo para calcular el puntaje total del equipo
        public int CalcularPuntaje()
        {
            int puntajeTotal = 0;
            foreach (var jugador in jugadores)
            {
                puntajeTotal += jugador.GetRendimiento();
            }
            return puntajeTotal;
        }

        // metodo para mostrar la información de todos los jugadores del equipo
        public void MostrarEquipo()
        {
            foreach (var jugador in jugadores)
            {
                jugador.MostrarInformacion();
            }
        }
    }

    // clase principal del programa
    class Program
    {
        static void Main(string[] args)
        {
            // crearlista de jugadores (máximo 6)
            List<Jugador> listaJugadores = new List<Jugador>()
            {
                new Jugador("Kevin Durant", "Base", 8),
                new Jugador("King James", "Base", 10), // Ajuste en el rendimiento a 10
                new Jugador("Chef Curry", "Alero", 6),
                new Jugador("Jimmy Butler", "Ala-Pívot", 9),
                new Jugador("Ja Morant", "Pívot", 5),
                new Jugador("Jayson Tatum", "Escolta", 7)
            };

            // crear los dos equipos
            Equipo equipo1 = new Equipo();
            Equipo equipo2 = new Equipo();

            // lista  para seleccionar jugadores disponibles
            List<Jugador> jugadoresDisponibles = new List<Jugador>(listaJugadores);

            Random rand = new Random();

            // seleccionar jugadores aleatoriamente y agregarlos a cada team 
            for (int i = 0; i < 3; i++)
            {
                // selección para el equipo 1
                int indiceAleatorio = rand.Next(jugadoresDisponibles.Count);
                Jugador jugadorSeleccionado = jugadoresDisponibles[indiceAleatorio];
                equipo1.AgregarJugador(jugadorSeleccionado);
                jugadoresDisponibles.RemoveAt(indiceAleatorio); // Eliminar jugador seleccionado

                // selección para el equipo 2
                indiceAleatorio = rand.Next(jugadoresDisponibles.Count);
                jugadorSeleccionado = jugadoresDisponibles[indiceAleatorio];
                equipo2.AgregarJugador(jugadorSeleccionado);
                jugadoresDisponibles.RemoveAt(indiceAleatorio); // Eliminar jugador seleccionado
            }

            // mostrar los jugadores de cada equipo
            Console.WriteLine("Equipo 1:");
            equipo1.MostrarEquipo();

            Console.WriteLine("\nEquipo 2:");
            equipo2.MostrarEquipo();

            // calcular el puntaje de cada equipo
            int puntajeEquipo1 = equipo1.CalcularPuntaje();
            int puntajeEquipo2 = equipo2.CalcularPuntaje();

            Console.WriteLine($"\nPuntaje Equipo 1: {puntajeEquipo1}");
            Console.WriteLine($"Puntaje Equipo 2: {puntajeEquipo2}");

            // se saca equipo ganador
            if (puntajeEquipo1 > puntajeEquipo2)
            {
                Console.WriteLine("\n¡El Equipo 1 es el ganador!");
            }
            else if (puntajeEquipo2 > puntajeEquipo1)
            {
                Console.WriteLine("\n¡El Equipo 2 es el ganador!");
            }
            else
            {
                Console.WriteLine("\n¡Es un empate!");
            }

            // presionar una tecla antes de cerrar el programa
            Console.ReadKey();
        }
    }
}
