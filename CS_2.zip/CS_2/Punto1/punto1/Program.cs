﻿using System;

//  interfaz para los pokemon
public interface IHabilidades
{
    int Atacar();
    double Defender();
}

// Clase abstracta que sirve para los Pokémon
public abstract class Pokemon : IHabilidades
{
    private string nombre;
    private string tipo;
    private int[] ataques = new int[3];
    private int defensa;

    // Constructor las propiedades de los pokemon
    public Pokemon(string nombre, string tipo, int ataque1, int ataque2, int ataque3, int defensa)
    {
        this.nombre = nombre;
        this.tipo = tipo;
        this.ataques[0] = ataque1;
        this.ataques[1] = ataque2;
        this.ataques[2] = ataque3;
        this.defensa = defensa;
    }

    // Método para atacar, selecciona un ataque al azar y lo multiplica por 1 o 0
    public int Atacar()
    {
        Random random = new Random();
        int ataqueSeleccionado = ataques[random.Next(0, 3)];
        int multiplicador = random.Next(0, 2); // 0 o 1
        return ataqueSeleccionado * multiplicador;
    }

    // Método para defender, multiplica la defensa por 1 o 0.5
    public double Defender()
    {
        Random random = new Random();
        double multiplicador = random.Next(0, 2) == 0 ? 1.0 : 0.5;
        return defensa * multiplicador;
    }

    //  acceder a la información del Pokémon
    public string Nombre => nombre;
    public string Tipo => tipo;
}

// Clase que hereda de Pokemon y permite crear pokemons personalizados
public class PokemonPersonalizado : Pokemon
{
    public PokemonPersonalizado(string nombre, string tipo, int ataque1, int ataque2, int ataque3, int defensa)
        : base(nombre, tipo, ataque1, ataque2, ataque3, defensa) { }
}

// Clase para ejecutar el combate
public class Program
{
    //  leer valores enteros de la consola
    public static int LeerEntero(string mensaje, int min, int max)
    {
        int valor;
        do
        {
            Console.WriteLine(mensaje);
        } while (!int.TryParse(Console.ReadLine(), out valor) || valor < min || valor > max);
        return valor;
    }

    //  crear un pokemon a partir de datos ingresados por consola
    public static Pokemon CrearPokemon()
    {
        Console.Write("Ingrese el nombre del Pokémon: ");
        string nombre = Console.ReadLine();

        Console.Write("Ingrese el tipo del Pokémon: ");
        string tipo = Console.ReadLine();

        int ataque1 = LeerEntero("Ingrese el valor del ataque 1 (0-40): ", 0, 40);
        int ataque2 = LeerEntero("Ingrese el valor del ataque 2 (0-40): ", 0, 40);
        int ataque3 = LeerEntero("Ingrese el valor del ataque 3 (0-40): ", 0, 40);
        int defensa = LeerEntero("Ingrese el valor de la defensa (10-35): ", 10, 35);

        return new PokemonPersonalizado(nombre, tipo, ataque1, ataque2, ataque3, defensa);
    }

    public static void Main(string[] args)
    {
        // Crear los dos pokemon segun lo q se meta por consola
        Console.WriteLine("Creación del Pokémon 1:");
        Pokemon pokemon1 = CrearPokemon();

        Console.WriteLine("\nCreación del Pokémon 2:");
        Pokemon pokemon2 = CrearPokemon();

        // llevar la cuenta de los turnos ganados por cada pokemon
        int puntosPokemon1 = 0;
        int puntosPokemon2 = 0;

        // Realizar tres turnos de combate
        for (int turno = 1; turno <= 3; turno++)
        {
            Console.WriteLine($"\n--- Turno {turno} ---");

            // Pokémon 1 ataca y Pokémon 2 defiende
            int ataque1 = pokemon1.Atacar();
            double defensa2 = pokemon2.Defender();
            double daño1 = Math.Max(ataque1 - defensa2, 0); // Daño calculado

            // Pokémon 2 ataca y Pokémon 1 defiende
            int ataque2 = pokemon2.Atacar();
            double defensa1 = pokemon1.Defender();
            double daño2 = Math.Max(ataque2 - defensa1, 0);

            // Mostrar resultados
            Console.WriteLine($"{pokemon1.Nombre} ataca con {ataque1}, {pokemon2.Nombre} defiende con {defensa2}, daño: {daño1}");
            Console.WriteLine($"{pokemon2.Nombre} ataca con {ataque2}, {pokemon1.Nombre} defiende con {defensa1}, daño: {daño2}");

            // evaluar el ganador del turno
            if (daño1 > daño2)
            {
                Console.WriteLine($"¡{pokemon1.Nombre} gana el turno {turno}!");
                puntosPokemon1++;
            }
            else if (daño2 > daño1)
            {
                Console.WriteLine($"¡{pokemon2.Nombre} gana el turno {turno}!");
                puntosPokemon2++;
            }
            else
            {
                Console.WriteLine("¡Es un empate en este turno!");
            }
        }

        // Mostrar el resultado final ps el ganador como tal
        Console.WriteLine("\n--- Resultado Final ---");
        if (puntosPokemon1 > puntosPokemon2)
        {
            Console.WriteLine($"¡{pokemon1.Nombre} ha ganado el combate!");
        }
        else if (puntosPokemon2 > puntosPokemon1)
        {
            Console.WriteLine($"¡{pokemon2.Nombre} ha ganado el combate!");
        }
        else
        {
            Console.WriteLine("¡El combate ha terminado en empate!");
        }
    }
}

